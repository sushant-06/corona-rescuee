import React from 'react';

export const Footer = (props) => (
    <footer>Copyright @Sourav Adak 2020</footer>
);